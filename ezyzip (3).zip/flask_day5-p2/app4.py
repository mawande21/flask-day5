from flask import render_template, Flask, request
from flask_mail import Mail, Message
import smtplib
app = Flask(__name__)

@app.route('/mail')
def mail():
    title = "Sending email to someone"
    return render_template('email.html', title=title)

@app.route('/form', methods=["POST"])
def form():
    # Getting from the form entries
    name = request.form.get('first_name')
    surname = request.form.get('last_name')
    email = request.form.get('email')



    # if you use gmail enter this smtp
    server = smtplib.SMTP("smtp.gmail.com", 587)

    #function
    server.starttls()

    #enter your email and password here
    server.login("your email", "Password ")

    #enter your email
    server.sendmail("your email", email,)

    title = "Hey! Thanks Pawl"
    return render_template('form.html', title=title, fname=name , sname=surname, email=email)

if __name__ == "__main__":
    app.run(debug=False)
